const SITE_URL = "https://ig-pro-max.vercel.app";
const SITE_NAME = "Instagram Pro Downloader";

export default { SITE_URL, SITE_NAME };
