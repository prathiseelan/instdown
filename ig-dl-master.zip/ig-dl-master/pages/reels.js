import Layout from "../components/Layout"
import DownloaderForm from '../components/DownloaderForm'
import Article from '../components/Article'
export default function Reels() {
    const title = "Instgram Reel Download"
    const description = "Save Instagram Reels quickly and easily with our efficient downloader tool."

    return (
    <>

    <Layout title={title} description={description}>
    <DownloaderForm title={title} description={description}/>


<Article>
<h2>Download Videos from Multiple Social Media Platforms</h2>
<img class="w-full" src="https://daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" />
<p>
All in One Video Downloader, aka AIO, offers you to download videos in multiple 
formats including MP4, M4A, 3GP from multiple social media platforms and sources.
 Also GIF, JPG and PNG image downloads are supported as well. AIO also includes 
 HD quality as a selection when downloading, if applicable. 
 All services provided on AIO is totally free.
Ever wished to download any video from any platform easily? 
It is very easy with allinonedownloader.com, any video or image, download twitter, download facebook, 
download instagram etc. to your mobile, PC or Mac easily in less than a minute.
</p>
</Article>




    </Layout>
    </>
        )
}