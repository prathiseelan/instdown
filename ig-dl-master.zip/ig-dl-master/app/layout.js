import { Inter } from "next/font/google";
import "./globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";
import DownloaderForm from "../components/DownloaderForm";

export default function RootLayout({ children,title }) {
  
  return (
    <html lang="en">
      <body className='container lg:px-40  mx-auto'>

      <Header/>

      
        {children}
        
     
        <Footer/>
        </body>
        
    </html>
  );
}
