import Config from '../config';
const { SITE_URL } = Config;

export default function robots() {
    return {
      rules: {
        userAgent: '*',
        allow: '/',
      },
      sitemap:  `${SITE_URL}/sitemap.xml`,
    }
  }