export default function Hero({ children, title, description }) {
  return (
    <>
      {title ? (
        <div className="hero bg-base-300">
          <div className="hero-content text-center">
            <div className="w-lg">
              <h1 className="py-2 text-3xl font-bold">{title}</h1>
              <p className="pb-5">{description}</p>
              {children}
            </div>
          </div>
        </div>
      ) : (
        <div className="hero bg-base-300">
        <div className="hero-content text-center">
          <div className="w-lg">
            <h1 className="py-2 text-3xl font-bold">Instagram Downloader</h1>
            <p className="pb-5">Save Instagram Photos, Videos, Reels quickly and easily with our efficient downloader tool.</p>
            {children}
          </div>
        </div>
      </div>
      )}
    </>
  );
}
