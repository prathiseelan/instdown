const MenuList = () => {
    const menuItems = [
      { label: 'Item 1', url: '/item1' },
      { label: 'Item 2', url: '/item2' },
      { label: 'Item 3', url: '/item3' }
    ];
  
    return (
      <>
        {menuItems.map((item, index) => (
          <li key={index}>
            <a href={item.url}>{item.label}</a>
          </li>
        ))}
      </>
    );
  };
  
  export default MenuList;
  