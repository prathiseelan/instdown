import Link from 'next/link'
import { TbPhoto } from "react-icons/tb";
import { BiMoviePlay } from "react-icons/bi";
import { RiVideoLine } from "react-icons/ri";

const CardList = () => {
  const menuItems = [
    { label: 'Reels', url: '/reels', icon: <BiMoviePlay size={24}/>, description: 'Save Instagram Reel quickly and easily with our efficient downloader tool' },
    { label: 'Photo', url: '/photo', icon: <TbPhoto size={24}/>, description: 'Save Instagram Photo quickly and easily with our efficient downloader tool' },
    { label: 'Video', url: '/video', icon: <RiVideoLine size={24}/>, description: 'Save Instagram Photo quickly and easily with our efficient downloader tool' },
  ];

  return (
    <>

<div className='containter'>
<div className='my-0  md:grid xl:grid-cols-3 lg:grid-cols-3 md:grid-cols-2 gap-2 justify-center'>

{menuItems.map((item, index) => (
<div key={index} class="card md:w-md bg-base-100 border shadow-xl">
  <div class="card-body">
    <h3 class="card-title">{item.label}</h3>
    <p>{item.description}.</p>
    <div class="card-actions justify-center">
    <Link className='btn btn-block btn-primary' href={item.url}>
    {item.icon} 
            Download {item.label} 
       </Link>
    </div>
  </div>
</div>

      ))}


</div>
</div>



     
    </>
  );
};

export default CardList;