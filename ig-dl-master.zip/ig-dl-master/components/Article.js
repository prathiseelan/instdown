export default function Article({children}){
    return(
        <>
<article class="prose-a:text-blue-800 prose-a:underline md:px-10 md:py-10 px-5 py-5 prose mx-auto prose-base lg:prose-lg">
{children}
</article>
        </>
    )
}