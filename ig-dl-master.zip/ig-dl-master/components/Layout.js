import Header from './Header'
import Footer from './Footer'
import Head from 'next/head';
import '../app/globals.css'

export default function Layout({ children,title,description }) {
  return (
    <>
       <Head>
       <title>{title}</title>
       <meta name="description" content={description} />
       <meta property="og:title" content={title}/>
    <meta property="og:description" content={description}/>
    <meta property="og:image:alt" content={title}/>
    <meta property="og:image:type" content="image/png"/>
    <meta property="og:image" content="/opengraph-image?6fea3eb190a4d7b0"/>
    <meta property="og:image:width" content="1200"/>
    <meta property="og:image:height" content="630"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:title" content={title}/>
    <meta name="twitter:description" content={description}/>
    <meta name="twitter:image:alt" content={title}/>
    <meta name="twitter:image:type" content="image/png"/>
    <meta name="twitter:image" content="/twitter-image?150dd0e7460a47b8"/>
    <meta name="twitter:image:width" content="1200"/>
    <meta name="twitter:image:height" content="630"/>
    <link rel="icon" href="/favicon.ico" type="image/x-icon" sizes="16x16"/>
    <link rel="icon" href="/icon?1eebc5942a361c24" type="image/png" sizes="48x48"/>
    <link rel="apple-touch-icon" href="/apple-icon.png?06a02fb9f98bd123" type="image/png" sizes="180x180"/>
      </Head>
      <div className='container lg:px-40  mx-auto'>
      <Header/>
      <main>
     

        {children}
        
        </main>
        <Footer/>
      </div>

    </>
  )
}