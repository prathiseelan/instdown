'use client'

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation'; // Correct import statement
import NumberFormatter from './NumberFormatter';
export default function DownloaderForm({ title, description }) {
  const router = useRouter();
  const [url, setUrl] = useState('');
  const [data, setData] = useState(null);
  const [shortcode, setShortcode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    if (shortcode) {
      fetchData();
    }
  }, [shortcode]); // Only depend on shortcode for this effect

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/${shortcode}`);
      const jsonData = await response.json();
      if (jsonData.id === "nopost") {
        setError('Post Not Found');
      } else {
        setData(jsonData);
        setError('');
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Error fetching data. Please try again.');
    } finally {
      setLoading(false); // Ensure loading state is updated
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const regex = /(?:\/(?:p|reel|[\w-]+)\/)([A-Za-z0-9-_]+)/;
    const match = url.match(regex);
    if (match) {
      setShortcode(match[1]);
    } else {
      setShortcode('');
      setError('Post not Found');
    }
  };

  const handlePasteFromClipboard = () => {
    navigator.clipboard.readText().then((text) => {
      setUrl(text);
    }).catch((error) => {
      console.error('Failed to read clipboard contents: ', error);
    });
  };

  return (
    <>

{data ? (
<div className='py-5'>
<div class="px-5 join w-full ">
  <input
  className="input focus:border-secondary border-primary border input-lg w-full join-item input-bordered"
  type="text"
  value={url}
  onChange={(e) => {
    setUrl(e.target.value);
  }}
  placeholder="Enter Instagram URL"
/>

  <button onClick={handlePasteFromClipboard} class="btn border-primary input-bordered btn-lg join-item">
    <svg stroke="currentColor" className='w-7' fill="currentColor" stroke-width="0" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M19 2h-4.18C14.4.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z"></path></svg>
  </button>
  <button onClick={handleSubmit} class="input-bordered border-primary btn btn-lg join-item">
  <span className='lg:block hidden'>Download</span>
  {loading ? 
    <span class="loading loading-spinner bg-gradient-to-r from-green-300 to-blue-300 via-red-500 to-purple-600"></span>

  : 
  <svg stroke="currentColor" className=' w-7' fill="currentColor" stroke-width="0" viewBox="0 0 24 24"  xmlns="http://www.w3.org/2000/svg"><path d="M3 19H21V21H3V19ZM13 13.1716L19.0711 7.1005L20.4853 8.51472L12 17L3.51472 8.51472L4.92893 7.1005L11 13.1716V2H13V13.1716Z"></path></svg>
}
    </button>
</div> 
<div class="mt-5 card w-full bg-base-300 ">
  <div class="card-body  justify-center">
    
   <div class="avatar justify-center">
  <div class="w-24 rounded-full">
    <img src={`/api/img?save=${encodeURIComponent(data.author.profile_pic_url)}`} />
  </div>
</div>
  <div class="flex justify-center">
    
    <span class="pr-2 text-center">@{data.author.username}</span>

    {data && data.author.is_verified === true ? (
  <svg
    aria-label="Verified"
    class="w-4"
    fill="rgb(0, 149, 246)"
    role="img"
    viewBox="0 0 40 40"
  >
    <title>Verified</title>
    <path
      d="M19.998 3.094 14.638 0l-2.972 5.15H5.432v6.354L0 14.64 3.094 20 0 25.359l5.432 3.137v5.905h5.975L14.638 40l5.36-3.094L25.358 40l3.232-5.6h6.162v-6.01L40 25.359 36.905 20 40 14.641l-5.248-3.03v-6.46h-6.419L25.358 0l-5.36 3.094Zm7.415 11.225 2.254 2.287-11.43 11.5-6.835-6.93 2.244-2.258 4.587 4.581 9.18-9.18Z"
      fill-rule="evenodd"
    ></path>
  </svg>
) : (
  <svg
  aria-label="Verified"
  class="w-4 fill-secondary"
  fill=""
  role="img"
  viewBox="0 0 40 40"
>
  <title>Not Verified</title>
  <path
    d="M19.998 3.094 14.638 0l-2.972 5.15H5.432v6.354L0 14.64 3.094 20 0 25.359l5.432 3.137v5.905h5.975L14.638 40l5.36-3.094L25.358 40l3.232-5.6h6.162v-6.01L40 25.359 36.905 20 40 14.641l-5.248-3.03v-6.46h-6.419L25.358 0l-5.36 3.094Zm7.415 11.225 2.254 2.287-11.43 11.5-6.835-6.93 2.244-2.258 4.587 4.581 9.18-9.18Z"
    fill-rule="evenodd"
  ></path>
</svg>
)}



</div>
<ul class="menu flex justify-center menu-horizontal">
  <li><a>Followers: <NumberFormatter number={data.author.edge_followed_by.count}/></a> </li>
  <li><a>Comments: <NumberFormatter number={data.comments}/></a></li>
  <li><a>Likes: <NumberFormatter number={data.likes} />  </a></li>
  
</ul>
{data && (
<div className='flex flex-wrap overflow-hidden justify-center'>




{data.media ? (


<>
{data.media.map((item, index) => (
 <div key={index} className="w-1/2 px-1 my-1 sm:w-1/2 sm:px-1 sm:my-1 md:w-1/3 md:px-1 md:my-1 lg:w-1/4 lg:px-1 lg:my-1 xl:w-1/4 xl:px-1 xl:my-1">

<div  class="card card-compact w-full bg-base-100 shadow-xl">
  
{item.node.__typename === "XDTGraphVideo" ? (
<div>

    <div class="card-body">
    <video className='card object-contain  w-full h-40' controls>
  <source src={`/api/img?save=${encodeURIComponent(item.node.video_url)}&dl=1`} type="video/mp4"/>
</video>
<div class="card-actions justify-center">
<div class="badge badge-secondary">Video</div>

      <a href={`${item.node.video_url}&dl=1`} target="_blank" class="btn btn-sm btn-primary">Download Video</a>
    </div>
    </div>
</div>
) : (
<div>


    <div class="card-body">
    <img className='object-contain  w-full h-40' src={`/api/img?save=${encodeURIComponent(item.node.display_url)}`} alt={item.node.accessibility_caption} />

<div class="card-actions justify-center">
<div class="badge badge-accent">Photo</div>

      <a href={`${item.node.display_url}&dl=1`} target="_blank" class="btn btn-block btn-primary">Download Photo</a>
    </div>
    </div>
</div>

)}
</div>
</div>
))}

        </>
        ): data.is_video === false ? (


          
<div className='flex flex-wrap overflow-hidden justify-center'>
 <div className="">
<div class="card md:w-md bg-base-100 border shadow-xl">
  <div class="card-body">
  <img className='card object-contain  h-48 w-96' src={`/api/img?save=${encodeURIComponent(data.photo_url)}`} alt={data.caption} />

    <div class="card-actions justify-center">
    <div class="badge badge-secondary">Photo</div>

    <a href={`${data.photo_url}&dl=1`} target="_blank" class="btn btn-block btn-primary">Download Photo</a>
    </div>
  </div>
</div>
 </div>
 </div>
        ) : 
        <div className='flex flex-wrap overflow-hidden justify-center'>
          
 <div className="w-lg">
<div class="card bg-base-100 border shadow-xl">
  
 
  
  <div class="card-body">
  <div class=" flex justify-center">
    <div class="badge badge-secondary">Video</div>
  </div>
  <video className='card  object-contain h-48 w-96' controls>
  <source src={`/api/img?save=${encodeURIComponent(data.video_url)}%26dl%3D1`} type="video/mp4"/>
</video>

    <a href={`${data.video_url}&dl=1`} target="_blank" class="btn btn-sm btn-primary">Download Video</a>

    <a href={`${data.photo_url}&dl=1`} target="_blank" class="btn btn-sm btn-primary">Download Thumbnail</a>

  </div>
</div>
 </div>
 </div>

        }
</div>
)}
  </div>
  
</div>
  </div>

):(
  <div className="hero">
  <div className="hero-content text-center">
    <div className="w-lg">
      <h1 className="py-2 text-3xl font-bold">{title}</h1>
      <p className="pb-5">{description}</p>
     
  <div class="join w-full " data-tip="hello">
  <input
  className="input border-2 input-lg w-full join-item input-bordered"
  type="text"
  value={url}
  onChange={(e) => {
    setUrl(e.target.value);
  }}
  placeholder="Enter Instagram URL"
/>

  <button onClick={handlePasteFromClipboard} class="btn input-bordered btn-lg join-item">
    <svg stroke="currentColor" className='w-7' fill="currentColor" stroke-width="0" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M19 2h-4.18C14.4.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z"></path></svg>
  </button>
  <button onClick={handleSubmit} class="input-bordered btn btn-lg join-item">
  <span className='lg:block hidden'>Download</span>
  {loading ? 
    <span class="loading loading-spinner bg-gradient-to-r from-green-300 to-blue-300 via-red-500 to-purple-600"></span>

  : 
  <svg stroke="currentColor" className=' w-7' fill="currentColor" stroke-width="0" viewBox="0 0 24 24"  xmlns="http://www.w3.org/2000/svg"><path d="M3 19H21V21H3V19ZM13 13.1716L19.0711 7.1005L20.4853 8.51472L12 17L3.51472 8.51472L4.92893 7.1005L11 13.1716V2H13V13.1716Z"></path></svg>
}
    </button>
</div>  

    </div>
  </div>
</div>

)}

</>
  );
}
